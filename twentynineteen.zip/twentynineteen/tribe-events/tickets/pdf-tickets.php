<?php
/**
 * Tickets Email Template
 * The template for the email with the purchased tickets when using ticketing plugins (Like WooTickets)
 *
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/tickets/email.php
 *
 * This file is being included in events/lib/tickets/Tickets.php
 *  in the function generate_tickets_email_content. That function has a $tickets
 *  array with elements that have this fields:
 *        $tickets[] = array( 'event_id',
 *                              'ticket_name'
 *                              'holder_name'
 *                              'order_id'
 *                              'ticket_id'
 *                              'security_code')
 *
 * @version 4.7.6
 *
 * @var array $tickets An array of tickets in the format documented above.
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<title><?php esc_html_e( 'Your tickets', 'event-tickets' ); ?></title>
	<meta name="viewport" content="width=device-width" />
	<style type="text/css">
		@font-face {
			font-family: Gotham-Book;
			src: url('http://primerenovationsnyc.com/files/fonts/Gotham-Book.ttf');
			font-weight: 400;
			font-style: normal
		}
		h1, h2, h3, h4, h5, h6 {
			color : #0a0a0e;
		}

		a, img {
			border  : 0;
			outline : 0;
		}

		#outlook a {
			padding : 0;
		}

		.ReadMsgBody, .ExternalClass {
			width : 100%
		}

		.yshortcuts, a .yshortcuts, a .yshortcuts:hover, a .yshortcuts:active, a .yshortcuts:focus {
			background-color : transparent !important;
			border           : none !important;
			color            : inherit !important;
		}

		body {
			background  : #ffffff;
			min-height  : 1000px;
			font-family : sans-serif;
			font-size   : 14px;
		}

		.appleLinks a {
			color           : #006caa;
			text-decoration : underline;
		}

		@media only screen and (max-width: 480px) {
			body, table, td, p, a, li, blockquote {
				-webkit-text-size-adjust : none !important;
			}

			body {
				width     : 100% !important;
				min-width : 100% !important;
			}

			body[yahoo] h2 {
				line-height : 120% !important;
				font-size   : 28px !important;
				margin      : 15px 0 10px 0 !important;
			}

			table.content,
			table.wrapper,
			table.inner-wrapper {
				width : 100% !important;
			}

			table.ticket-content {
				width   : 90% !important;
				padding : 20px 0 !important;
			}

			table.ticket-details {
				position       : relative;
				padding-bottom : 100px !important;
			}

			table.ticket-break {
				width : 100% !important;
			}

			td.wrapper {
				width : 100% !important;
			}

			td.ticket-content {
				width : 100% !important;
			}

			td.ticket-image img {
				max-width : 100% !important;
				width     : 100% !important;
				height    : auto !important;
			}

			td.ticket-details {
				width         : 33% !important;
				padding-right : 10px !important;
				border-top    : 1px solid #ddd !important;
			}

			td.ticket-details h6 {
				margin-top : 20px !important;
			}

			td.ticket-details.new-row {
				width      : 50% !important;
				height     : 80px !important;
				border-top : 0 !important;
				position   : absolute !important;
				bottom     : 0 !important;
				display    : block !important;
			}

			td.ticket-details.new-left-row {
				left : 0 !important;
			}

			td.ticket-details.new-right-row {
				right : 0 !important;
			}

			table.ticket-venue {
				position       : relative !important;
				width          : 100% !important;
				padding-bottom : 150px !important;
			}

			td.ticket-venue,
			td.ticket-organizer,
			td.ticket-qr {
				width      : 100% !important;
				border-top : 1px solid #ddd !important;
			}

			td.ticket-venue h6,
			td.ticket-organizer h6 {
				margin-top : 20px !important;
			}

			td.ticket-qr {
				text-align : left !important
			}

			td.ticket-qr img {
				float      : none !important;
				margin-top : 20px !important
			}

			td.ticket-organizer,
			td.ticket-qr {
				position : absolute;
				display  : block;
				left     : 0;
				bottom   : 0;
			}

			td.ticket-organizer {
				bottom : 0px;
				height : 100px !important;
			}

			td.ticket-venue-child {
				width : 50% !important;
			}

			table.venue-details {
				position : relative !important;
				width    : 100% !important;
			}

			a[href^="tel"], a[href^="sms"] {
				text-decoration : none;
				color           : black;
				pointer-events  : none;
				cursor          : default;
			}

			.mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
				text-decoration : default;
				color           : #006caa !important;
				pointer-events  : auto;
				cursor          : default;
			}
		}

		@media only screen and (max-width: 320px) {
			td.ticket-venue h6,
			td.ticket-organizer h6,
			td.ticket-details h6 {
				font-size : 12px !important;
			}
		}

		@media print {
			.ticket-break {
				page-break-before : always !important;
			}
		}

		<?php do_action( 'tribe_tickets_ticket_email_styles' );?>

	</style>
</head>
<body yahoo="fix" alink="#006caa" link="#006caa" text="#000000" bgcolor="#005581" style="width:100% !important; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; margin:0 auto; padding:0; background:#005581; min-height:1000px;">
	<div style="margin:0; background-color:#005581; padding:10px 0; width:600px !important; font-family: Gotham, 'Helvetica Neue', Helvetica, sans-serif; font-size:14px; text-align:center;">
		<?php
		do_action( 'tribe_tickets_ticket_email_top' );

		$count = 0;
		$break = '';
		foreach ( $tickets as $ticket ) {
			$count ++;

			if ( $count == 2 ) {
				$break = 'page-break-before:always !important;';
			}

			$event      = get_post( $ticket['event_id'] );
			$header_id  = get_post_meta( $ticket['event_id'], tribe( 'tickets.handler' )->key_image_header, true );
			$header_img = false;

			/**
			 * If the ticket is a WooCommerce product and has a featured image,
			 * display it on email.
			 *
			 * @since 4.7.4
			 */
			if ( 'Tribe__Tickets_Plus__Commerce__WooCommerce__Main' === $ticket['provider'] && class_exists( 'WC_Product' ) ) {
				$product  = new WC_Product( $ticket['product_id'] );
				$image_id = $product->get_image_id();
				if ( ! empty( $image_id ) ) {
					$header_img = wp_get_attachment_image_src( $image_id, 'full' );
				}
			}

			if ( ! empty( $header_id ) ) {
				$header_img = wp_get_attachment_image_src( $header_id, 'full' );
			}

			/**
			 * Filters the ticket image that will be included in the tickets email
			 *
			 * @since 4.7.6
			 *
			 * @param bool|string $header_img False or header image src
			 * @param int         $header_id  Parent post ticket header image ID if set
			 * @param array       $ticket     Ticket information
			 */
			$header_img  = apply_filters( 'tribe_tickets_email_ticket_image', $header_img, $header_id, $ticket );

			$venue_label = '';
			$venue_name = null;

			if ( function_exists( 'tribe_get_venue_id' ) ) {
				$venue_id = tribe_get_venue_id( $event->ID );
				if ( ! empty( $venue_id ) ) {
					$venue = get_post( $venue_id );
				}

				$venue_label = tribe_get_venue_label_singular();

				$venue_name = $venue_phone = $venue_address = $venue_city = $venue_web = '';
				if ( ! empty( $venue ) ) {
					$venue_name    = $venue->post_title;
					$venue_phone   = get_post_meta( $venue_id, '_VenuePhone', true );
					$venue_address = get_post_meta( $venue_id, '_VenueAddress', true );
					$venue_city    = get_post_meta( $venue_id, '_VenueCity', true );
					$venue_state   = get_post_meta( $venue_id, '_VenueStateProvince', true );
					if ( empty( $venue_state ) ) {
						$venue_state = get_post_meta( $venue_id, '_VenueState', true );
					}
					if ( empty( $venue_state ) ) {
						$venue_state = get_post_meta( $venue_id, '_VenueProvince', true );
					}
					$venue_zip     = get_post_meta( $venue_id, '_VenueZip', true );
					$venue_web     = get_post_meta( $venue_id, '_VenueURL', true );
				}

				// $venue_address_style: make sure no double-quotes in the content
				$venue_address_style = "display:block; margin:0; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size:13px;";

				$venue_map_url = '';

				if ( true === tribe_show_google_map_link( $event->ID ) && $venue_id ) {
					$venue_map_url = esc_url( tribe_get_map_link( $venue_id ) );
				}

				if ( empty( $venue_map_url ) ) {
					$venue_address_tag = 'span';
				} else {
					$venue_address_tag = 'a';
					$venue_address_style .= ' color:#006caa !important; text-decoration:underline;';
				}
			}

			$event_date = null;

			/**
			 * Filters whether or not the event date should be included in the ticket email.
			 *
			 * @since 4.5.11
			 * @since 4.7.4    Include event date default value changed to true
			 *
			 * @var bool Include event date? Defaults to true.
			 * @var int  Event ID
			 */
			$include_event_date = apply_filters( 'tribe_tickets_email_include_event_date', true, $event->ID );

			if ( $include_event_date && function_exists( 'tribe_events_event_schedule_details' ) ) {
				$event_date = tribe_events_event_schedule_details( $event );
			}

			if ( function_exists( 'tribe_get_organizer_ids' ) ) {
				$organizers = tribe_get_organizer_ids( $event->ID );
			}

			$event_link = function_exists( 'tribe_get_event_link' ) ? tribe_get_event_link( $event->ID ) : get_post_permalink( $event->ID );

			?>
			<div style="width:70%; margin-left:15%; border-radius:5px; background-color:#FFF; text-align:center; padding:10px;">
				<?php
					/**
					 * Gives an opportunity to manipulate the current ticket before output
					 *
					 * @since  4.7.4
					 *
					 * @param  array $ticket Current ticket information
					 */
					do_action( 'tribe_tickets_ticket_email_ticket_top', $ticket );
				?>
				<h2 style="font-family: 'Gotham-Book', Helvetica, sans-serif; font-size:22px;"><strong><?php echo $ticket['ticket_name']; ?></strong></h2>
				<?php if ( ! empty( $event_date ) ) : ?>
					<h4 style="font-family: Gotham-Book, Helvetica, sans-serif; font-weight:400; font-size:18px;"><?php echo $event_date; ?></span></h4>
				<?php endif; ?>
				<?php if ( $venue_name || ! empty( $organizers ) ) { ?>
					<?php if ( $venue_name ) {	?>
						<span style="font-family: Gotham, Helvetica, sans-serif; font-size:18px;"><strong><?php echo $venue_name; ?></span></strong><br />
						<?php echo $venue_address; ?><br />
						<?php if ( $venue_city && ( $venue_state || $venue_zip ) ) :
							printf( '%s, %s %s', $venue_city, $venue_state, $venue_zip );
						else:
							echo $venue_city;
						endif; ?>
						<span style="font-family: Gotham, Helvetica, sans-serif; font-size:18px;"><?php echo $venue_phone; ?></span>
						<?php if ( ! empty( $venue_web ) ): ?>
							<a href="<?php echo esc_url( $venue_web ) ?>" style="color:#006caa !important; display:block; margin:0; font-family: 'Gotham-Book', 'Helvetica Neue', Helvetica, sans-serif; font-size:18px; text-decoration:underline;"><?php echo $venue_web; ?></a>
						<?php endif; ?>
					<?php }	?>																					
				<?php } ?>	
				<h6 style="font-family: Gotham, Helvetica, sans-serif; text-transform:uppercase; font-size:13px;"><strong><?php esc_html_e( 'Attendee Information', 'event-tickets-plus' ); ?></strong></h6>			
				<?php 
					foreach($attendee_metadatas as $attendee_metadata) {
    					echo '<strong>Attendee Name:</strong><br />' . $attendee_metadata['attendee-name'] . '<br />';
					}
				?>
				<?php echo 'QR Ticket ID:' . $ticket['qr_ticket_id'] . '<br />' ?>
				<?php /* 
					$current_ticket_id	= $ticket['qr_ticket_id'];
					var_dump($current_ticket_id);
					$trimmed = trim($current_ticket_id);
					var_dump($trimmed);

					$attendee_metadatas = tribe_get_event_meta($current_ticket_id,'_tribe_tickets_meta',false ); 
						print_r($attendee_metadatas);
				?>
		<hr />
				<?php 
					$current_ticket_id1	= 46882;
					$attendee_metadatas1 = tribe_get_event_meta( $current_ticket_id1, '_tribe_tickets_meta', false ); 
						print_r($attendee_metadatas1); */
				?>
				<?php do_action( 'tribe_tickets_ticket_email_ticket_bottom', $ticket ); ?>
				<hr style="width:60%; margin-left:20%;"/>
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:13px;"><strong>TICKET #</strong></span><br />
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:15px;"><?php echo $ticket['ticket_id']; ?></span><br /><br />
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:13px;"><strong>PURCHASER</strong></span><br />
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:15px;"><?php echo $ticket['holder_name']; ?></span><br /><br />
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:13px;"><strong>SECURITY CODE</strong></span><br />
				<span style="font-family: Gotham, Helvetica, sans-serif; font-size:15px;"><?php echo $ticket['security_code']; ?></span>
				<hr style="width:60%; margin-left:20%;"/>
				<img src="https://jewishdetroit.org/wp-content/uploads/2013/07/brand-guide-horizontal-logo.png">
			</div>
		<?php }//end foreach
		do_action( 'tribe_tickets_ticket_email_bottom' );
		?>
	</div>
</body>
</html>