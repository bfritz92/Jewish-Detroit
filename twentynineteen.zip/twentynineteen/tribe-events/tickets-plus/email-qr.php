<?php
/**
 * QR code insert in tickets email
 *
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/tickets-plus/email-qr.php
 *
 * @version 4.7.6
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<table class="content" align="center" width="620" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" style="margin:15px auto 0; padding:0;">
	<tr>
		<td align="center" valign="top" class="wrapper" width="620">
			<table class="inner-wrapper" border="0" cellpadding="0" cellspacing="0" width="620" bgcolor="#f7f7f7" style="margin:0 auto !important; width:620px; padding:0;">
				<tr>
					<td valign="top" class="ticket-content" align="center" width="100%" border="0" cellpadding="20" cellspacing="0" style="padding:20px; background:#fff;">
						<img src="<?php echo esc_url( $qr ); ?>" width="250" height="250" alt="QR Code Image" style="border:0; outline:none; height:auto; max-width:100%; display:block;"/>					
						<h3 style="color:#0a0a0e; margin:0 0 10px 0 !important; font-family: 'Gotham', Helvetica Neue', Helvetica, sans-serif; font-weight:700; font-size:28px; letter-spacing:normal; text-align:center;line-height: 100%;">
							<strong><span style="color:#0a0a0e !important"><?php esc_html_e( 'Check in for this event', 'event-tickets-plus' ); ?></span></strong>		
						</h3>
						<p style="font-family: Gotham, 'Helvetica Neue', Helvetica, Arial, 'sans-serif'">
							<a href="mailto:Enter%20an%20email?subject=Your%20Subject%20Line&body=Thought%20you%20might%20be%20interested%20in%20this%20<?php echo esc_url( $qr ); ?><img src=%22<?php echo esc_url( $qr ); ?>%22>">
Forward to a friend</a><br><?php esc_html_e( 'Scan this QR code at the event to check in.', 'event-tickets-plus' ); ?>
						</p>
						
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>