<?php
/**
 * Single Event Content Template Part
 *
 * Override this template in your own theme by creating a file at:
 * [your-theme]/tribe/events/single-event/content.php
 *
 * See more documentation about our Blocks Editor templating system.
 *
 * @link {INSERT_ARTCILE_LINK_HERE}
 *
 * @version 4.7
 *
 */
?>

<?php 
	$event_id	= $this->get( 'post_id' );
	$organizer	= $this->attr( 'organizer' );
	$co_chairs	= get_field('event_co_chairs');
	$special_pr	= get_field('event_price_special');
	$regform	= get_field('gravity_form_id');
	$qrcode		= get_field('qr_code_needed');
 ?>
<ul class="individual-event--info">		
	<li class="location"><?php echo tribe_get_venue( $venue_id ); ?>, <?php echo tribe_get_address( $venue_id ); ?>, <?php echo tribe_get_city( $venue_id ); ?> <?php echo tribe_get_state( $venue_id ); ?> <?php echo tribe_get_zip( $venue_id ); ?></li>	
	<li class="date"><?php echo tribe_get_start_date( $post->ID, false, 'l' ); ?>, <?php echo tribe_get_start_date( $post->ID, false, 'F' ); ?> <?php echo tribe_get_start_date( $post->ID, false, 'jS' ); ?> at <?php echo tribe_get_start_date(null, false, 'g:i a'); ?></li>
	<?php if ($special_pr) : ?>
		<li class="price"><?php echo $special_pr ?></li>
	<?php else : ?>
		<li class="price"><?php echo tribe_get_cost( null, true ) ?></li>
	<?php endif; ?>
	<li class="contact"> <?php echo tribe_get_organizer( $organizer ); ?> <?php if (tribe_get_organizer_phone( $organizer )) : ?>- <?php echo tribe_get_organizer_phone( $organizer ); ?><?php endif; ?></li>	
</ul>
<?php if( have_rows('event_co_chairs') || have_rows('event_committee') ): ?>
	<section class="individual-event--details">    
<?php else: ?>	
	<section class="individual-event--details" style="grid-template-columns: 6fr;"> 		
<?php endif; ?>			
	<div class="individual-event--details--copy">
		<?php the_content(); ?>
	</div>
	<?php if( have_rows('event_co_chairs') || have_rows('event_committee') ): ?>
	<div class="individual-event--details--leadership">
		<?php if( have_rows('event_co_chairs') ): ?>	
		<ul>
			<li><h4 class="blue baskerville">Event Co-Chairs</h4></li>
			<?php while ( have_rows('event_co_chairs') ) : the_row(); ?>
				<li><?php the_sub_field('co_chair_name'); ?></li>
			<?php endwhile; ?>
		</ul>			
		<?php endif; ?>		
		<?php if( have_rows('event_committee') ): ?>	
		<ul>
			<li><h4 class="blue baskerville">Event Committee</h4></li>
			<?php while ( have_rows('event_committee') ) : the_row(); ?>
				<li><?php the_sub_field('event_committee_name'); ?></li>
			<?php endwhile; ?>
		</ul>			
		<?php endif; ?>
	</div>
	<?php endif; ?>
</section>	
<div class="entry-content">
	<p>&nbsp;</p>
	<?php if ($regform) : ?>
		<?php if ($qrcode == 'yes') : ?>
			<?php echo do_shortcode('[gravityform id="'.$regform.'" title="false" description="false" ajax="false"]')?>
		<?php else : ?>
			<?php echo do_shortcode('[gravityform id="'.$regform.'" title="false" description="false" ajax="true"]')?>
		<?php endif; ?>
	<?php endif; ?>
</div>

