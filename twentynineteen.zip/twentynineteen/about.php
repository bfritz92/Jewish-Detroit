<?php
/**
* Template Name: About Us
 * 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */

get_header();
?>

<section class="about-page">
    <img class="about-page--logo" src="https://2019.jewishdetroit.org/wp-content/uploads/2019/05/logo-solo-color.svg">
    <h1 class="about-page--title baskerville center">Here for Good</h1>
    <p class="about-page--copy center bold">Along with our 17 local and three international partner agencies, the Jewish Federation of Metropolitan Detroit takes responsibility for the health, safety, education and spiritual well-being of Detroit’s Jewish community. We are here to honor the past. We are here to strengthen the present. We are here to protect the future. We are here for good. And as a Federation, we say “Hineni.” </p>

    <div class="about-page--filmstrip">
        <img class="about-page--flimstrip--img" src="">
        <img class="about-page--flimstrip--img" src="">
        <img class="about-page--flimstrip--img" src="">
        <img class="about-page--flimstrip--img" src="">
    </div>
</section>
    
<section class="about-page--part-two grid">
    <div class="about-page--part-two--copy">
        <h2 class="about-page--heading pt2 pb1 baskerville center">Hineni — I am here. </h2>
        <p class="bold">This simple statement is more than just an acknowledgment of our presence. Hineni is the response given by both Abraham and Moses when called upon by G-d, signifying their absolute willingness to be of service. Hineni is essential to the mission of the Jewish Federation: to take care of the needs of the Jewish people and build a vibrant Jewish future in Detroit, in Israel and around the world.</p>
    </div>
 <picture class="about-page--part-two--img" alt="">
    <source srcset="<?php echo wp_get_attachment_image_srcset( 41970) ?>">
        <img src="<?php echo wp_get_attachment_image_url( 41970, 'large' ) ?>">
    </picture>

    </section>
</section>

<section class="about-page--part-three grid">
    <div class="about-page--part-three--copy ">
        <p class="pt3 bold">Our values are built upon a foundation of commitment, responsibility and active participation. And just like our forefathers who first uttered this sentiment, we are also here to be of service, to do our part in healing the world and to make a positive difference in the lives we touch. Hineni. </p>
        <h2 class="about-page--heading pt1 baskerville">We are here for good.</h2>
    </div>
    <div class="about-page--part-three--img" alt="">
        <img srcset="<?php echo wp_get_attachment_image_srcset( 41797) ?>">
       
</div>
</section>



<?php
get_footer();
