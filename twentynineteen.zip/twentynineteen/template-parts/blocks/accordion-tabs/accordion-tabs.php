<?php
/**
 * Accordion Tabs Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */
// Create id attribute allowing for custom "anchor" value.
$id = 'accordion-tabs-' . $block['id'];
if( !empty($block['anchor']) ) {
   $id = $block['anchor'];
}
// Create class attribute allowing for custom "className" and "align" values.
$className = 'accordion-tabs';
if( !empty($block['className']) ) {
   $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
   $className .= ' align' . $block['align'];
}
// Load values and assing defaults.
$fpip = get_field('block_accordion_tabs');
?>
<!--Markup for Expand/Collapse-->
<?php
	// check if the flexible content field has rows of data
	if( have_rows('block_accordion_tabs') ):		
		 // loop through the rows of data
?>
<?php $have_image = get_field('have_image'); ?>
<?php if ($have_image) : ?>
	<section id="content" class="accordion-tabs fade pt-2 <?php echo $className ?>">
<?php else : ?>
	<section id="content" class="accordion-tabs fade pt-2 narrow <?php echo $className ?>">
<?php endif;?>
	<h2 class="book mb1 baskerville"><?php the_field('accordion_header',$post_id); ?></h2>
	<article class="tabbed-content tabs-side">
		<nav class="tabs">
			<ul>
				<?php
					$a = 1;
					while ( have_rows('block_accordion_tabs') ) : the_row();
					$header = get_sub_field('header');
					$byline = get_sub_field('byline'); 
					$body = get_sub_field('body'); 
					$link = get_sub_field('link');
					
				?>	
				<!--ACF  tab--title -->
				<?php if ($a == 1) : ?>
					<li><a href="#side_tab<?php echo $a++; ?>" class="active"><?php the_sub_field('header');?></a></li>
				<?php else : ?>
					<li><a href="#side_tab<?php echo $a++; ?>" class=""><?php the_sub_field('header');?></a></li>
				<?php endif; ?>
				<?php
				endwhile;
				?>
			</ul>
		 </nav>
				<?php
					$b = 1;
					while ( have_rows('block_accordion_tabs') ) : the_row();
					$header = get_sub_field('header');
					$byline = get_sub_field('byline'); 
					$body = get_sub_field('body'); 
					$link = get_sub_field('link');
					$image = get_sub_field('image');
				?>
					<?php if ($b == 1) : ?>
				  		<section id="side_tab<?php echo $b++; ?>" class="item active" data-title="<?php the_sub_field('header');?>">
					<?php else : ?>
						<section id="side_tab<?php echo $b++; ?>" class="item" data-title="<?php the_sub_field('header');?>">	
					<?php endif; ?>							
					<div class="item-content">
						<!--ACF START tab-copy -->
						<h3 class="mt0"><?php the_sub_field('header');?></h3>
						<?php the_sub_field('body');?>
						<?php if ($image) : ?>
							<img src="<?php echo $image; ?>">		
						<?php endif; ?>
						<!--ACF END tab-copy -->
					</div>
					
				  </section>
				<?php
				endwhile;
				?>
	<?php else : ?>
	<!--	// no layouts found -->
	<?php endif; ?>				

			
	</article>	
</section>